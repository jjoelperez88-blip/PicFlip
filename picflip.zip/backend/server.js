/**
 * Picflip backend — user accounts + cross-device sync
 * ------------------------------------------------
 * Zero-dependency Node.js server. Run with:  node server.js
 *
 * Endpoints:
 *   POST /api/register   { email, password }  -> create account
 *   POST /api/login      { email, password }  -> get a token
 *   GET  /api/state      (Authorization: Bearer <token>)  -> get saved state
 *   PUT  /api/state      (Authorization: Bearer <token>)  -> save state
 *
 * Data is stored in a plain JSON file (data.json). Perfect for a starter;
 * swap in a real database (Postgres/SQLite) when you scale.
 */

const http = require("http");
const crypto = require("crypto");
const fs = require("fs");
const path = require("path");

const PORT = process.env.PORT || 3000;
const DATA_FILE = path.join(__dirname, "data.json");
const SECRET = process.env.PICFLIP_SECRET || crypto.randomBytes(32).toString("hex");

// ---------- tiny JSON-file database ----------
function loadDb() {
  try { return JSON.parse(fs.readFileSync(DATA_FILE, "utf8")); }
  catch { return { users: {} }; }
}
function saveDb(db) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(db, null, 2));
}

// ---------- password hashing (built-in scrypt) ----------
function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString("hex");
  const hash = crypto.scryptSync(password, salt, 64).toString("hex");
  return `${salt}:${hash}`;
}
function verifyPassword(password, stored) {
  const [salt, hash] = stored.split(":");
  const check = crypto.scryptSync(password, salt, 64).toString("hex");
  return crypto.timingSafeEqual(Buffer.from(hash, "hex"), Buffer.from(check, "hex"));
}

// ---------- tokens (HMAC-signed, base64url so emails with dots are safe) ----------
const b64 = s => Buffer.from(s).toString("base64url");
const unb64 = s => Buffer.from(s, "base64url").toString("utf8");
function makeToken(email) {
  const payload = b64(`${email}|${Date.now()}`);
  const sig = crypto.createHmac("sha256", SECRET).update(payload).digest("base64url");
  return `${payload}.${sig}`;
}
function verifyToken(token) {
  const parts = token.split(".");
  if (parts.length !== 2) return null;
  const [payload, sig] = parts;
  const expected = crypto.createHmac("sha256", SECRET).update(payload).digest("base64url");
  if (expected !== sig) return null;
  const [email, ts] = unb64(payload).split("|");
  if (!email || !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return null;
  // tokens expire after 30 days
  if (Date.now() - Number(ts) > 30 * 24 * 60 * 60 * 1000) return null;
  return email;
}

// ---------- helpers ----------
function send(res, code, obj) {
  res.writeHead(code, { "Content-Type": "application/json" });
  res.end(JSON.stringify(obj));
}
function readBody(req) {
  return new Promise((resolve, reject) => {
    let data = "";
    req.on("data", c => { data += c; if (data.length > 1e7) reject(new Error("too large")); });
    req.on("end", () => { try { resolve(JSON.parse(data || "{}")); } catch (e) { reject(e); } });
    req.on("error", reject);
  });
}
function validEmail(e) { return typeof e === "string" && /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(e); }

// ---------- routes ----------
const server = http.createServer(async (req, res) => {
  // CORS so the browser can call from a different origin
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET, POST, PUT, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");
  if (req.method === "OPTIONS") { res.writeHead(204); return res.end(); }

  const url = new URL(req.url, `http://${req.headers.host}`);
  const db = loadDb();

  try {
    // Register
    if (req.method === "POST" && url.pathname === "/api/register") {
      const { email, password } = await readBody(req);
      const em = (email || "").trim().toLowerCase();
      if (!validEmail(em)) return send(res, 400, { error: "Invalid email" });
      if (!password || password.length < 6) return send(res, 400, { error: "Password must be at least 6 characters" });
      if (db.users[em]) return send(res, 409, { error: "An account with that email already exists" });
      db.users[em] = { email: em, pass: hashPassword(password), created: Date.now(), state: {} };
      saveDb(db);
      return send(res, 201, { token: makeToken(em), email: em, state: {} });
    }

    // Login
    if (req.method === "POST" && url.pathname === "/api/login") {
      const { email, password } = await readBody(req);
      const em = (email || "").trim().toLowerCase();
      const u = db.users[em];
      if (!u || !verifyPassword(password || "", u.pass)) return send(res, 401, { error: "Incorrect email or password" });
      return send(res, 200, { token: makeToken(em), email: em, state: u.state || {} });
    }

    // Authorized routes below
    const auth = (req.headers.authorization || "").replace("Bearer ", "");
    const email = verifyToken(auth);
    if (!email) return send(res, 401, { error: "Not authorized — please log in again" });
    const u = db.users[email];
    if (!u) return send(res, 401, { error: "Account not found" });

    // Get state
    if (req.method === "GET" && url.pathname === "/api/state") {
      return send(res, 200, { email, state: u.state || {} });
    }

    // Save state
    if (req.method === "PUT" && url.pathname === "/api/state") {
      const { state } = await readBody(req);
      if (!state || typeof state !== "object") return send(res, 400, { error: "state must be an object" });
      u.state = state;
      saveDb(db);
      return send(res, 200, { ok: true });
    }

    return send(res, 404, { error: "Not found" });
  } catch (e) {
    send(res, 400, { error: e.message || "Bad request" });
  }
});

server.listen(PORT, () => {
  console.log(`\n  Picflip backend running on http://localhost:${PORT}`);
  console.log(`  Register:  POST /api/register  {email,password}`);
  console.log(`  Login:     POST /api/login     {email,password}`);
  console.log(`  Get state: GET  /api/state     (Bearer token)`);
  console.log(`  Save state:PUT  /api/state     {state}` + "\n");
});
