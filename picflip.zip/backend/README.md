# Picflip Backend — Accounts + Cloud Sync

A tiny, **zero-dependency** Node.js server that gives Picflip real user accounts and
cross-device sync. No `npm install` needed — it only uses Node's built-in modules.

## What it does

| Feature | Endpoint | What it does |
|---|---|---|
| Create account | `POST /api/register` | Sign up with email + password |
| Log in | `POST /api/login` | Get a token for that account |
| Download data | `GET /api/state` | Get your saved scans/items/sales |
| Upload data | `PUT /api/state` | Save your data to the cloud |

Data is stored in a plain `data.json` file. Passwords are hashed with Node's built-in
scrypt (never stored in plain text). Tokens are HMAC-signed and expire after 30 days.

## Run it locally (2 steps)

```bash
# 1. Make sure Node is installed  (check with:  node --version)
cd backend
node server.js
```

You'll see it listening on `http://localhost:3000`.

Then open the app with the backend URL so it knows where to sync:

```
http://localhost:3000   (backend)
http://localhost:8000/reselling-app-prototype.html?api=http://localhost:3000
```

Serve the app itself however you like, e.g.:

```bash
python3 -m http.server 8000
```

Go to **Settings → Account & Sync → Set up**, create an account, and your data will
start syncing to the backend. Open the app on another device, log in, and tap **Sync now**
to pull everything down. Everything still works fully offline if the server is down.

## Test it with curl

```bash
# Register
curl -X POST http://localhost:3000/api/register -H "Content-Type: application/json" \
  -d '{"email":"you@example.com","password":"secret123"}'

# Login -> returns a token
curl -X POST http://localhost:3000/api/login -H "Content-Type: application/json" \
  -d '{"email":"you@example.com","password":"secret123"}'

# Save state (put the token in here)
curl -X PUT http://localhost:3000/api/state -H "Authorization: Bearer <TOKEN>" \
  -H "Content-Type: application/json" -d '{"state":{"pro":true,"history":[]}}'

# Get state
curl http://localhost:3000/api/state -H "Authorization: Bearer <TOKEN>"
```

## Deploy it (get a real URL)

For a beginner, **Render** or **Railway** are the friendliest free hosts:

1. Push `server.js` to a GitHub repo.
2. Create a free account at **render.com** → **New → Web Service** → connect the repo.
3. Build command: leave blank. Start command: `node server.js`.
4. Render gives you a URL like `https://picflip-backend.onrender.com`.
5. Also set an env var `PICFLIP_SECRET` to a long random string (so tokens stay valid
   across restarts — otherwise they reset each deploy).
6. Open the app as:
   `https://your-app-url/reselling-app-prototype.html?api=https://picflip-backend.onrender.com`

> ⚠️ **Security note for later:** this uses a JSON file, which is fine for a starter but
> not for heavy traffic. Before launch, swap the storage for a real database (Postgres or
> SQLite) and add HTTPS + rate-limiting. That's a natural next step when you scale.

## When you sell the website

This backend (accounts + data sync) is one of the main things buyers expect to see, so
it directly adds to the site's resale value — real accounts and cloud sync prove the
product is more than a static demo.
